<?php
// Conexión a la base de datos (reemplaza con tus propios datos)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rent car";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener datos del formulario (valida y limpia los datos para evitar la inyección de SQL)
$nombre = mysqli_real_escape_string($conn, $_POST['nombre']);
$apellidos = mysqli_real_escape_string($conn, $_POST['apellidos']);
$correo = mysqli_real_escape_string($conn, $_POST['correo']);
$telefono = mysqli_real_escape_string($conn, $_POST['telefono']);
$lugarEntrega = mysqli_real_escape_string($conn, $_POST['lugarEntrega']);
$lugarRecogida = mysqli_real_escape_string($conn, $_POST['lugarRecogida']);
$fechaRecogida = mysqli_real_escape_string($conn, $_POST['fechaRecogida']);
$horaRecogida = mysqli_real_escape_string($conn, $_POST['horaRecogida']);
$comentarios = mysqli_real_escape_string($conn, $_POST['comentarios']);
$payment = mysqli_real_escape_string($conn, $_POST['payment']);
    
// Obtener el stock actual
$sql_stock_actual = "SELECT cantidad FROM stock_carros WHERE id = 1";
$result_stock_actual = $conn->query($sql_stock_actual);

if ($result_stock_actual !== false) {
    if ($result_stock_actual->num_rows > 0) {
        $row = $result_stock_actual->fetch_assoc();
        $stock_actual = $row["cantidad"];

        // Verificar si hay suficiente stock
        if ($stock_actual > 0) {
            // Decrementar el stock después de la reserva
            $sql_update_stock = "UPDATE stock_carros SET cantidad = cantidad - 1 WHERE id = 1";
            $conn->query($sql_update_stock);

            // Insertar información del cliente en la tabla clientes
            $sql_cliente = "INSERT INTO clientes (nombre, apellidos, correo, telefono) VALUES ('$nombre', '$apellidos', '$correo', '$telefono')";

            if ($conn->query($sql_cliente) === TRUE) {
                // Obtener el ID del cliente recién insertado
                $id_cliente = $conn->insert_id;

                // Insertar información de la reserva en la tabla reservas3
                $sql_reserva = "INSERT INTO reservas3 (id_cliente, nombre, apellidos, correo, telefono, lugar_entrega, lugar_recogida, fecha_recogida, hora_recogida, comentarios, tipo_pago) VALUES ($id_cliente, '$nombre', '$apellidos', '$correo', '$telefono', '$lugarEntrega', '$lugarRecogida', '$fechaRecogida', '$horaRecogida', '$comentarios', '$payment')";

                if ($conn->query($sql_reserva) === TRUE) {
                    echo "Reserva realizada con éxito. Gracias por elegirnos.";
                } else {
                    echo "Error al procesar la reserva: " . $conn->error;
                }
            } else {
                echo "Error al registrar al cliente: " . $conn->error;
            }
        } else {
            echo "Lo sentimos, no hay carros disponibles en este momento.";
        }
    } else {
        echo "Error al obtener el stock de carros: No se encontraron resultados.";
    }
} else {
    // Mostrar un mensaje de error si la consulta falla
    echo "Error en la consulta: " . $conn->error;
}

// Realizar la consulta para obtener el stock
$result_stock = $conn->query("SELECT cantidad FROM stock_carros");

// Verificar si la consulta fue exitosa
if ($result_stock !== false) {
    // Obtener el resultado de la consulta
    $row_stock = $result_stock->fetch_assoc();

    // Almacenar el stock en una variable
    $stockDisponible = $row_stock['cantidad'];
    echo "Stock disponible de carros: " . $stockDisponible;
} else {
    echo "Error al obtener el stock de carros: " . $conn->error;
}

// Cerrar la conexión
$conn->close();
?>
