document.addEventListener("DOMContentLoaded", function () {
    // Datos de ejemplo para las noticias
    const noticias = [
        {
            title: "Nueva tecnología de motores",
            description: "Se presenta un motor revolucionario que promete mayor eficiencia y menor consumo de combustible.",
            image: "img/messi/noticia1.jpg",
            link: "#"
        },
        
        // Puedes agregar más noticias según sea necesario
    ];

    const blogContainer = document.querySelector(".blog-container");

    // Filtrar las noticias para obtener solo aquellas con la imagen específica
    const noticiasFiltradas = noticias.filter(noticia => noticia.image === "img/messi/WhatsApp Image 2023-11-10 at 14.56.24.jpg");

    // Agregar noticias dinámicamente al contenedor
    noticiasFiltradas.forEach((noticia, index) => {
        const blogCard = document.createElement("div");
        blogCard.classList.add("blog-card");

        const image = document.createElement("img");
        image.classList.add("blog-image");
        image.src = noticia.image;
        image.alt = `Imagen de ${noticia.title}`;

        const content = document.createElement("div");
        content.classList.add("blog-content");

        const title = document.createElement("div");
        title.classList.add("blog-title");
        title.textContent = noticia.title;

        const description = document.createElement("div");
        description.classList.add("blog-description");
        description.textContent = noticia.description;

        content.appendChild(title);
        content.appendChild(description);

        blogCard.appendChild(image);
        blogCard.appendChild(content);

        // Agregar el evento de clic para redirigir a la noticia completa
        blogCard.addEventListener("click", () => {
            window.location.href = noticia.link;
        });

        blogContainer.appendChild(blogCard);
    });
});
 