<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recuperar datos del formulario
    $lugarRecogida = $_POST['lugarRecogida'];
    $lugarEntrega = $_POST['lugarEntrega'];
    $fechaRecogida = $_POST['fechaRecogida'];
    $horaRecogida = $_POST['horaRecogida'];
    $comentarios = $_POST['comentarios'];
    $metodoPago = $_POST['payment'];

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "rent car";

   
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("INSERT INTO procesar_reserva (lugarRecogida, lugarEntrega, fechaRecogida, horaRecogida, comentarios, metodoPago) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $lugarRecogida, $lugarEntrega, $fechaRecogida, $horaRecogida, $comentarios, $metodoPago);

    if ($stmt->execute()) {
        echo "Gracias por tu reserva";
        echo "<br>";
        echo "<a href='menu_administrador.html'><button>Volver al menú</button></a>";
    } else {
        echo "Error al procesar la reserva: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>
