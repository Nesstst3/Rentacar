<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
    $nombre = isset($_POST['nombre']) ? $_POST['nombre'] : '';
    $apellidos = isset($_POST['apellidos']) ? $_POST['apellidos'] : '';
    $correo = isset($_POST['correo']) ? $_POST['correo'] : '';
    $telefono = isset($_POST['telefono']) ? $_POST['telefono'] : '';
    $lugarRecogida = isset($_POST['lugarrecogida']) ? $_POST['lugarrecogida'] : '';
    $lugarEntrega = isset($_POST['lugarentrega']) ? $_POST['lugarentrega'] : '';
    $fechaRecogida = isset($_POST['fecharecogida']) ? $_POST['fecharecogida'] : '';
    $horaRecogida = isset($_POST['horarecogida']) ? $_POST['horarecogida'] : '';
    $comentarios = isset($_POST['comentarios']) ? $_POST['comentarios'] : '';
    $metodoPago = isset($_POST['payment']) ? $_POST['payment'] : '';

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "rent car";  

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }


    $stmt = $conn->prepare("INSERT INTO reservas3 (nombre, apellidos, correo, telefono, lugar_recogida, lugar_entrega, fecha_recogida, hora_recogida, comentarios, tipo_pago) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    if ($stmt) {
        $stmt->bind_param("ssssssssss", $nombre, $apellidos, $correo, $telefono, $lugarrecogida, $lugarrntrega, $fecharecogida, $horarecogida, $comentarios, $metodopago);

        if ($stmt->execute()) {
            echo "Gracias por tu reserva";
            echo "<br>";
            echo "<a href='menu_administrador.html'><button>Volver al menú</button></a>";
        } else {
            echo "Error al procesar la reserva: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error en la preparación de la consulta: " . $conn->error;
    }

    $conn->close();
}
?>

