-- Active: 1700763569827@@127.0.0.1@3306@rent car

CREATE TABLE contactanos (
    `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `nombre` VARCHAR(255) NOT NULL,
    `correo` VARCHAR(255) NOT NULL,
    `tema` VARCHAR(255) NOT NULL,
    `mensaje` TEXT NOT NULL,
    `fecha_creacion` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE informacionpersonalrenta (
    `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `nombre` VARCHAR(255) NOT NULL,
    `apellidos` VARCHAR(255) NOT NULL,
    `correo` VARCHAR(255) NOT NULL,
    `telefono` VARCHAR(20) NOT NULL,
    `fecha_creacion` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE detallesderenta (
    `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `id_info_personal` INT(11) UNSIGNED,
    `sucursal_recoger` VARCHAR(255) NOT NULL,
    `lugar_entrega` VARCHAR(255) NOT NULL,
    `pickup_date` DATE NOT NULL,
    `pickup_time` TIME NOT NULL,
    `comentarios` TEXT,
    `tipo_pago` VARCHAR(20),
    `fecha_creacion` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`id_info_personal`) REFERENCES `informacionpersonalrenta`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE  personal_detail (
    `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `first_name` VARCHAR(255) NOT NULL,
    `last_name` VARCHAR(255) NOT NULL,
    `email` VARCHAR(255) NOT NULL,
    `mobile_number` VARCHAR(20) NOT NULL,
    `date_created` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE booking_detail (
    `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `pickup_location` VARCHAR(255) NOT NULL,
    `drop_location` VARCHAR(255) NOT NULL,
    `pickup_date` DATE NOT NULL,
    `pickup_time` TIME NOT NULL,
    `adults` INT(11) NOT NULL,
    `children` INT(11) NOT NULL,
    `special_request` TEXT,
    `personal_detail_id` INT(11) UNSIGNED,
    `date_created` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`personal_detail_id`) REFERENCES `personal_detail`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE payment_detail (
    `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `payment_method` VARCHAR(255) NOT NULL,
    `booking_detail_id` INT(11) UNSIGNED,
    `date_created` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`booking_detail_id`) REFERENCES `booking_detail`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE stock_carros (
    `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `cantidad` INT(11) NOT NULL,
    `fecha_actualizacion` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


INSERT INTO `stock_carros` (`cantidad`) VALUES (10);

CREATE TABLE  infoperenta (
    `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `nombre` VARCHAR(255) NOT NULL,
    `apellidos` VARCHAR(255) NOT NULL,
    `correo` VARCHAR(255) NOT NULL,
    `telefono` VARCHAR(20) NOT NULL,
    `fecha_creacion` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE opiniones (
    `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `nombre` VARCHAR(255) NOT NULL,
    `email` VARCHAR(255) NOT NULL,
    `tema` VARCHAR(255) NOT NULL,
    `mensaje` TEXT NOT NULL,
    `fecha_creacion` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE procesar_reserva (
    `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `lugarRecogida` VARCHAR(255) NOT NULL,
    `lugarEntrega` VARCHAR(255) NOT NULL,
    `fechaRecogida` DATE NOT NULL,
    `horaRecogida` TIME NOT NULL,
    `comentarios` TEXT,
    `metodoPago` VARCHAR(255) NOT NULL,
    `fecha_creacion` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




INSERT IGNORE INTO `stock_carros` (`id`, `cantidad`) VALUES (1, 10);


CREATE TABLE  clientes (
    `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `nombre` VARCHAR(255) NOT NULL,
    `apellidos` VARCHAR(255) NOT NULL,
    `correo` VARCHAR(255) NOT NULL,
    `telefono` VARCHAR(20) NOT NULL,
    `fecha_creacion` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE reservas3 (
    `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `id_cliente` INT(11) UNSIGNED NOT NULL,
    `nombre` VARCHAR(255) NOT NULL,
    `apellidos` VARCHAR(255) NOT NULL,
    `correo` VARCHAR(255) NOT NULL,
    `telefono` VARCHAR(20) NOT NULL,
    `lugar_entrega` VARCHAR(255) NOT NULL,
    `lugar_recogida` VARCHAR(255) NOT NULL,
    `fecha_recogida` DATE NOT NULL,
    `hora_recogida` TIME NOT NULL,
    `comentarios` TEXT,
    `tipo_pago` VARCHAR(255) NOT NULL,
    `fecha_creacion` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`id_cliente`) REFERENCES `clientes`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `stock_carros` (`cantidad`) VALUES (30);

INSERT IGNORE INTO `stock_carros` (`id`, `cantidad`) VALUES (1, 30);
ALTER TABLE reservas3 MODIFY lugar_recogida VARCHAR(255) NULL;
ALTER TABLE reservas3 MODIFY lugar_entrega VARCHAR(255) NULL;
ALTER TABLE reservas3 MODIFY fecha_recogida DATE NOT NULL;

CREATE TABLE reservasenojado (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    apellidos VARCHAR(255) NOT NULL,
    correo VARCHAR(255) NOT NULL,
    telefono VARCHAR(15) NOT NULL,
    payment VARCHAR(50) NOT NULL,
    lugarEntrega INT NOT NULL,
    lugarRecogida INT NOT NULL,
    fechaRecogida DATE NOT NULL,
    horaRecogida TIME NOT NULL,
    comentarios TEXT NOT NULL,
    fechaCreacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE detailenojado (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    apellidos VARCHAR(255) NOT NULL,
    correo VARCHAR(255) NOT NULL,
    telefono VARCHAR(20) NOT NULL,
    payment VARCHAR(50) NOT NULL,
    lugarEntrega INT NOT NULL,
    lugarRecogida INT NOT NULL,
    fechaRecogida DATE NOT NULL,
    horaRecogida TIME NOT NULL,
    comentarios TEXT,
    fechaCreacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
