<?php
// Archivo para procesar la reserva

include('db_config.php'); // Incluye el archivo de configuración de la base de datos

// Recopilar datos del formulario
$nombre = $_POST['nombre'];
$apellidos = $_POST['apellidos'];
$correo = $_POST['correo'];
$telefono = $_POST['telefono'];
$payment = $_POST['payment'];
$lugarEntrega = $_POST['lugarEntrega'];
$lugarRecogida = $_POST['lugarRecogida'];
$fechaRecogida = $_POST['fechaRecogida'];
$horaRecogida = $_POST['horaRecogida'];
$comentarios = $_POST['comentarios'];

// Validar y limpiar los datos
$nombre = filter_var($nombre, FILTER_SANITIZE_STRING);
$apellidos = filter_var($apellidos, FILTER_SANITIZE_STRING);
$correo = filter_var($correo, FILTER_SANITIZE_EMAIL);
$telefono = filter_var($telefono, FILTER_SANITIZE_STRING);
$payment = filter_var($payment, FILTER_SANITIZE_STRING);
$lugarEntrega = filter_var($lugarEntrega, FILTER_VALIDATE_INT);
$lugarRecogida = filter_var($lugarRecogida, FILTER_VALIDATE_INT);
$fechaRecogida = filter_var($fechaRecogida, FILTER_SANITIZE_STRING);
$horaRecogida = filter_var($horaRecogida, FILTER_SANITIZE_STRING);
$comentarios = filter_var($comentarios, FILTER_SANITIZE_STRING);

// Verificar la validez de los datos, por ejemplo, si los campos obligatorios no están vacíos
if (empty($nombre) || empty($apellidos) || empty($correo) || empty($telefono) || empty($payment) || empty($lugarEntrega) || empty($lugarRecogida) || empty($fechaRecogida) || empty($horaRecogida)) {
    echo json_encode(['success' => false, 'error' => 'Por favor, completa todos los campos antes de enviar el formulario.']);
    exit;
}

// Preparar la consulta SQL para insertar en la tabla 'reservas'
$sql = "INSERT INTO reservasenojado (nombre, apellidos, correo, telefono, payment, lugarEntrega, lugarRecogida, fechaRecogida, horaRecogida, comentarios) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

// Preparar la declaración
$stmt = $mysqli->prepare($sql);

// Vincular los parámetros
$stmt->bind_param("sssssiisss", $nombre, $apellidos, $correo, $telefono, $payment, $lugarEntrega, $lugarRecogida, $fechaRecogida, $horaRecogida, $comentarios);

// Ejecutar la consulta
if ($stmt->execute()) {
    // La reserva se ha realizado con éxito
    echo json_encode(['success' => true, 'message' => '¡Muchas gracias por tu reserva!']);
} else {
    // Hubo un error al realizar la reserva
    echo json_encode(['success' => false, 'error' => 'Error desconocido al realizar la reserva.']);
}

// Cerrar la conexión y liberar recursos
$stmt->close();
$mysqli->close();
?>
