<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Información personal
    $nombre = $_POST['nombre'];
    $apellidos = $_POST['apellidos'];
    $correo = $_POST['correo'];
    $telefono = $_POST['telefono'];

    // Detalles de la renta
    $sucursalRecoger = $_POST['sucursalRecoger'];
    $lugarEntrega = $_POST['lugarEntrega'];
    $pickupDate = $_POST['pickupDate'];
    $pickupTime = $_POST['pickupTime'];
    $comentarios = $_POST['comentarios'];
    $tipoPago = isset($_POST['payment']) ? $_POST['payment'] : '';

    // Conexión a la base de datos
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "rent car";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    // Insertar información personal en la tabla informacionpersonalrenta
    $sqlInfoPersonal = "INSERT INTO informacionpersonalrenta (nombre, apellidos, correo, telefono) 
                        VALUES ('$nombre', '$apellidos', '$correo', '$telefono')";

    if ($conn->query($sqlInfoPersonal) === TRUE) {
        // Obtener el ID recién insertado
        $idInfoPersonal = $conn->insert_id;

        // Insertar detalles de la renta en la tabla detallesderenta
        $sqlDetallesRenta = "INSERT INTO detallesderenta (id_info_personal, sucursal_recoger, lugar_entrega, pickup_date, pickup_time, comentarios, tipo_pago) 
                             VALUES ('$idInfoPersonal', '$sucursalRecoger', '$lugarEntrega', '$pickupDate', '$pickupTime', '$comentarios', '$tipoPago')";

        if ($conn->query($sqlDetallesRenta) === TRUE) {
            echo "Reserva realizada con éxito. Gracias por elegir Rent a Car.";
        } else {
            echo "Error al insertar detalles de la renta: " . $conn->error;
        }
    } else {
        echo "Error al insertar información personal: " . $conn->error;
    }

    $conn->close();
}
?>
