<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $tema = $_POST['tema'];
    $mensaje = $_POST['mensaje'];

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "rent car";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    // Use prepared statements to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO opiniones(nombre, email, tema, mensaje) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $nombre, $email, $tema, $mensaje);

    if ($stmt->execute()) {
        echo "Gracias por tu mensaje";
        echo "<br>";
        echo "<a href='menu_administrador.html'><button>Volver al menú</button></a>";
    } else {
        echo "Error al crear el cliente: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>
