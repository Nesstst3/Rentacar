document.addEventListener('DOMContentLoaded', function () {
    const blogContainer = document.getElementById('blog-container');

    // Datos simulados de noticias (puedes reemplazar esto con datos reales)
    const noticias = [
        { titulo: 'Nueva tecnología de automóviles eléctricos', contenido: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.' },
        { titulo: 'Mejoras en la seguridad de los vehículos', contenido: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.' },
        { titulo: 'Top 10 de autos deportivos del año', contenido: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.' }
        // Agrega más noticias según sea necesario
    ];

    function mostrarNoticias() {
        noticias.forEach((noticia) => {
            const article = document.createElement('article');
            article.classList.add('blog-post');

            const titulo = document.createElement('h2');
            titulo.textContent = noticia.titulo;

            const contenido = document.createElement('p');
            contenido.textContent = noticia.contenido;

            article.appendChild(titulo);
            article.appendChild(contenido);
            blogContainer.appendChild(article);
        });
    }

    // Muestra las primeras noticias al cargar la página
    mostrarNoticias();

    // Agrega un botón para cargar más noticias
    const loadMoreBtn = document.createElement('button');
    loadMoreBtn.textContent = 'Cargar más noticias';
    loadMoreBtn.classList.add('load-more-btn');
    loadMoreBtn.addEventListener('click', mostrarNoticias);

    blogContainer.appendChild(loadMoreBtn);
});
