<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validar el correo electrónico
    $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
    if (!$email) {
        echo "El correo electrónico no es válido";
        exit;
    }

    // Otros campos de validación según sea necesario...

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "rent car";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    // Iniciar transacción
    $conn->begin_transaction();

    try {
        // Insertar información personal y obtener el ID generado
        $stmt = $conn->prepare("INSERT INTO personal_detail (first_name, last_name, email, mobile_number) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $first_name, $last_name, $email, $mobile_number);
        $stmt->execute();
        $personal_detail_id = $stmt->insert_id;
        $stmt->close();

        // Insertar detalles de reserva asociados con la información personal
        $stmt = $conn->prepare("INSERT INTO booking_detail (pickup_location, drop_location, pickup_date, pickup_time, adults, children, special_request, personal_detail_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssiissi", $pickup_location, $drop_location, $pickup_date, $pickup_time, $adults, $children, $special_request, $personal_detail_id);
        $stmt->execute();
        $booking_detail_id = $stmt->insert_id;
        $stmt->close();

        // Insertar detalles de pago asociados con los detalles de reserva
        $stmt = $conn->prepare("INSERT INTO payment_detail (payment_method, booking_detail_id) VALUES (?, ?)");
        $stmt->bind_param("si", $payment_method, $booking_detail_id);

        if ($stmt->execute()) {
            // Confirmar transacción si todas las operaciones fueron exitosas
            $conn->commit();

            echo "Gracias por tu reserva";
            echo "<br>";
            echo "<script>";
            echo "document.addEventListener('DOMContentLoaded', function() {";
            echo "  var notification = document.createElement('div');";
            echo "  notification.innerHTML = 'Gracias por tu reserva';";
            echo "  notification.className = 'notification';";
            echo "  document.body.appendChild(notification);";
            echo "  setTimeout(function() {";
            echo "    document.body.removeChild(notification);";
            echo "  }, 3000);"; // La notificación desaparecerá después de 3 segundos
            echo "});";
            echo "</script>";
            exit; // Importante: asegúrate de salir para evitar que el resto del código se ejecute
        } else {
            throw new Exception("Error al ejecutar la consulta de pago");
        }
    } catch (Exception $e) {
        // Revertir transacción en caso de error
        $conn->rollback();

        echo "Error al realizar la reserva: " . $e->getMessage();
    }

    $stmt->close();
    $conn->close();
}
?>

