<?php
// Conexión a la base de datos (reemplaza con tus propios datos)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rent car";

// Intentar la conexión a la base de datos
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener datos del formulario
$nombre = $_POST['nombre'];
$apellidos = $_POST['apellidos'];
$correo = $_POST['correo'];
$telefono = $_POST['telefono'];
$lugarEntrega = $_POST['lugarEntrega'];
$lugarRecogida = $_POST['lugarRecogida'];
$fechaRecogida = $_POST['fechaRecogida'];
$horaRecogida = $_POST['horaRecogida'];
$comentarios = $_POST['comentarios'];
$payment = $_POST['payment'];

// Validar los datos si es necesario
// Aquí deberías realizar cualquier validación adicional y procesamiento de datos según tus necesidades.

// Ejemplo: Insertar datos en la base de datos
$sql_insert = "INSERT INTO reservas3 (nombre, apellidos, correo, telefono, lugar_entrega, lugar_recogida, fecha_recogida, hora_recogida, comentarios, tipo_pago) VALUES ('$nombre', '$apellidos', '$correo', '$telefono', '$lugarEntrega', '$lugarRecogida', '$fechaRecogida', '$horaRecogida', '$comentarios', '$payment')";

if ($conn->query($sql_insert) === TRUE) {
    echo "Reserva realizada con éxito.";
} else {
    echo "Error al realizar la reserva: " . $conn->error;
}

// Cerrar la conexión
$conn->close();
?>
