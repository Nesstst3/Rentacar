<?php
// Conexión a la base de datos (reemplaza con tus propios datos)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rent_car";

// Intentar la conexión a la base de datos
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener la cantidad de carros disponibles desde la base de datos
$sql_stock = "SELECT cantidad FROM stock_carros WHERE id = 1";
$result = $conn->query($sql_stock);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $stockDisponible = $row["cantidad"];
    echo json_encode(["success" => true, "stock" => $stockDisponible]);
} else {
    // Si no hay resultados, asigna un valor predeterminado
    $stockDisponible = 0;
    echo json_encode(["success" => false, "error" => "No se encontraron resultados"]);
}

// Cerrar la conexión
$conn->close();
?>
