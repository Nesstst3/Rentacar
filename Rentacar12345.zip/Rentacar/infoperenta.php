<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recuperar datos del formulario
    $nombre = $_POST['nombre'];
    $apellidos = $_POST['apellidos'];
    $correo = $_POST['correo'];
    $telefono = $_POST['telefono'];

    // Configuración de la base de datos
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "rent car";

    // Crear conexión a la base de datos
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Verificar la conexión
    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    // Utilizar sentencias preparadas para evitar la inyección de SQL
    $stmt = $conn->prepare("INSERT INTO infoperenta (nombre, apellidos, correo, telefono) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $nombre, $apellidos, $correo, $telefono);

    // Ejecutar la sentencia
    if ($stmt->execute()) {
        echo "Gracias por tu mensaje";
        echo "<br>";
        echo "<a href='menu_administrador.html'><button>Volver al menú</button></a>";
    } else {
        echo "Error al crear el cliente: " . $conn->error;
    }

    // Cerrar la conexión y la sentencia preparada
    $stmt->close();
    $conn->close();
}
?>
